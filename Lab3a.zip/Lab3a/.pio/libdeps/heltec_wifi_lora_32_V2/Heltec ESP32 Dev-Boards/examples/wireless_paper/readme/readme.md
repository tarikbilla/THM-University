1.修改程序中
![Alt text](image-1.png)
来连接wifi。
编译，烧录程序
2.待初始化完成后,访问wireless_paper IP地址，IP可以在串口助手查看![Alt text](image.png)
3.出现如下页面![\img](image-2.png)
点击![Alt text](image-3.png)选择图片，为保证刷新效果最好选择黑白的bmp格式图片，图片大小应设置为250×122。
按钮会显示文件地址，如图![Alt text](image-4.png)
5.点击Get image data按钮，获取图片数据，图片会显示在画布上。效果如下：![
](image-5.png)
6.点击refresh按钮，在墨水屏上刷新图片。